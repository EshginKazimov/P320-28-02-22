﻿using System.Collections.Generic;

namespace P320Practise.Models
{
    public class Category
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Image { get; set; }

        public bool IsMain { get; set; }

        public bool IsDeleted { get; set; }

        public Category Parent { get; set; }

        public ICollection<Category> Children { get; set; }
    }
}
